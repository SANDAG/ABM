import os, subprocess, time
ts = time.clock()
for i in range(300):
    print "Starting run", i, "time:", round(time.clock()-ts,2), "Mins:", round((time.clock()-ts)/60,2), "Hours:", round((time.clock()-ts)/3600,2)
    subprocess.call("cvm.bat")
    os.rename("./Outputs/Gen and trip summ.csv", "./Outputs/Gen_trip_sum_"+str(i)+".csv")
    
    os.rename("./Outputs/SDCVM_Summary.csv", "./Outputs/OD_sum_"+str(i)+".csv")    
print "Done!"

