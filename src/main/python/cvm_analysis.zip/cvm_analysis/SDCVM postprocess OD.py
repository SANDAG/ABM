import csv
import time

class excelOne(csv.excel):
    # define CSV dialect for Excel to avoid blank lines from default \r\n
    lineterminator = "\n"     

ts = time.clock()

timePeriods = settings.cvmTimes
industries = settings.cvmSectors
path = "./Outputs/"

fout = open(path + "Trip_SDCVM.csv", "w")
foutSum = open(path + "SDCVM_Summary.csv", "w")
outFile = csv.writer(fout, excelOne)
outFileSum = csv.writer(foutSum, excelOne)
outFileSum.writerow(["Industry", "Mode", "Time", "O", "D", "Count"])

noHead = True
q = 0

fin = open("tazGroup.csv", "r")
inFile = csv.reader(fin)
header = inFile.next()
tazDict = {}
for row in inFile:
    tazDict[row[header.index("TAZ")]] = row[header.index("MSA")]
fin.close()
print "Read in MSA directory"

for ind in industries:
    sumDict = {}
    for per in timePeriods:
        print 50 * "-"
        print "Opening industry", ind, "time period", per, ":", round(time.clock()-ts, 2)
        fin = open(path + "Trip_" + ind + "_" + per + ".csv", "r")
        inFile = csv.reader(fin)
        header = inFile.next()
        if noHead == True:
            noHead = False
            #outFile.writerow(header)

        for row in inFile:
            row[header.index("ActorType")] = ind
            #outFile.writerow(row)
            i = tazDict[row[header.index("I")]]
            j = tazDict[row[header.index("J")]]
            
            key = (row[header.index("Mode")], row[header.index("Time")], i, j)
            if sumDict.has_key(key):
                sumDict[key] +=1
            else:
                sumDict[key] = 1

            q += 1
            if q % 50000 == 0:
                print "    read", q/1000000.0, "million trips overall.", round(time.clock()-ts, 2)
    keyList = sumDict.keys()
    for key in keyList:
        outRow = [ind, key[0], key[1], key[2], key[3], sumDict[key]]
        outFileSum.writerow(outRow)

fout.close()
foutSum.close()
print "DonE!", round(time.clock(), 2), i
        
