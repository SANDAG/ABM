import csv, time
import settings, sdcvm

# External libraries
ts = time.clock()
class excelOne(csv.excel):
    # define CSV dialect for Excel to avoid blank lines from default \r\n
    lineterminator = "\n"  

def roundby5(x, base=5):
    return int(base * round(float(x)/base))

cvmPath = "./Outputs/"
freq = {}
for ind in settings.cvmSectors:
    for tim in settings.cvmTimes:
        print ind, tim,  round(time.clock()-ts, 2)
        fin = open(cvmPath + "Trip_" + ind + "_" + tim + ".csv", "r")
        inFile = csv.reader(fin)
        header = inFile.next()
        for row in inFile:
            mode = row[header.index("Mode")]
            starttimes = float(row[header.index("StartTime")])
            hour=int(starttimes)
            minute=(roundby5(60*(starttimes-hour)))
            if hour>=96: #control for long time tours
                hour -= 96
            if hour>=72:
                hour -= 72
            if hour>=48:
                hour -= 48
            if hour>=24:
                hour -= 24
            starttimesrnd=float(hour)+(float(minute)/60) #recombine rounded minutes and hours
            if starttimesrnd==24: #control for round up to midnight (24) and round down to midnight (0)
                starttimesrnd=0
            #print(starttimes,hour,minute,starttimesrnd)
            freq[starttimesrnd]=freq.get(starttimesrnd,0)+1 
            print(freq[starttimesrnd])

# write out TOD frequencies
fout = open(cvmPath + "Trip_TOD_Summary.csv", "w")
outFile = csv.writer(fout, excelOne)

header = ["StartTime", "Freq"]
outFile.writerow(header)

for starttime in sorted(freq.keys()):
    outrow=(starttime,freq[starttime])
    outFile.writerow(outrow)
fout.close()
