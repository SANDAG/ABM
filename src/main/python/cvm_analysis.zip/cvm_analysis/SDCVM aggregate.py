import csv, time
import settings, sdcvm

# External libraries
ts = time.clock()
class excelOne(csv.excel):
    # define CSV dialect for Excel to avoid blank lines from default \r\n
    lineterminator = "\n"  


cvmPath = "./Outputs/"
timeDict = {}
fout = open(cvmPath + "Trip_all_all.csv", "w")
outFile = csv.writer(fout, excelOne)
headWrite = True
x = 0
for ind in settings.cvmSectors:
    for tim in settings.cvmTimes:
        print ind, tim,  round(time.clock()-ts, 2), x
        fin = open(cvmPath + "Trip_" + ind + "_" + tim + ".csv", "r")
        inFile = csv.reader(fin)
        header = inFile.next()
        if headWrite:
            outFile.writerow(header)
            headWrite = False
        for row in inFile:
            outFile.writerow(header)
            x = x + 1

fout.close()
print "Combined", x, "trips into", cvmPath + "Trip_all_all.csv"
