import csv, time
import settings, sdcvm

# External libraries
ts = time.clock()
class excelOne(csv.excel):
    # define CSV dialect for Excel to avoid blank lines from default \r\n
    lineterminator = "\n"  

tazList, zonals = sdcvm.zonalProperties(fileName = settings.cvmZonalProperties)
tazDict = {}
#tazList = tazList[:25]
for t in range(len(tazList)):
    tazDict[tazList[t]] = t


# Read in skims

print "Reading in CVM skims. Time:", round(time.clock()-ts, 2)    
skimDict = {}
skimList = []


print "... Midday distance",  round(time.clock()-ts, 2) 
skimList.append("Dist_Mid")
skimDict = sdcvm.csvSkim(tazList, tazList, tazDict, tazDict,
                   settings.skimPath + "impdat_MD_Dist.TXT", skimDict, "Dist_Mid")



cvmPath = "./Outputs/"
bigDict = {}
for ind in settings.cvmSectors:
    for tim in settings.cvmTimes:
        print ind, tim,  round(time.clock()-ts, 2) 
        fin = open(cvmPath + "Trip_" + ind + "_" + tim + ".csv", "r")
        inFile = csv.reader(fin)
        header = inFile.next()
        for row in inFile:
            mode = row[header.index("Mode")]
            print "mode", mode
            trip = int(row[header.index("Trip")])
            print "trip", trip
            purp = row[header.index("TourType")]
            print "purp", purp
            home = int(row[header.index("HomeZone")])
            print "home", home
            iTaz = int(row[header.index("I")])
            print "iTAZ", iTaz
            jTaz = int(row[header.index("J")])
            print "jTAZ", jTaz

            iIdx = tazList.index(iTaz)
            print "iIdx", iIdx
            jIdx = tazList.index(jTaz)
            print "jIdx", jIdx
            newjIdx=jIdx + 12
            print "newjIdx", newjIdx

            key = (ind, mode, purp, home)
            print "key", key
            if bigDict.has_key(key):
                pass
            else:
                bigDict[key] = [0, 0, 0, 0]

            bigDict[key][1] = bigDict[key][1] + 1
            print bigDict[key][1]
            bigDict[key][2] = bigDict[key][2] + skimDict["Dist_Mid"][iIdx][newjIdx]
            print bigDict[key][2]
            print"skimdist", skimDict["Dist_Mid"][iIdx][newjIdx]
            break
            if trip == 1:
                bigDict[key][0] = bigDict[key][0] + 1
            if iTaz == jTaz:
                bigDict[key][3] = bigDict[key][3] + 1

fout = open(cvmPath + "Gen and trip summ.csv", "w")
outFile = csv.writer(fout, excelOne)

keyList = bigDict.keys()
keyList.sort()
header = ["Industry", "Mode", "Purpose", "TAZ", "Tours", "Trips", "Dist", "Intra"]
outFile.writerow(header)


for key in keyList:
    outRow = list(key)
    outRow.extend(bigDict[key])
    outFile.writerow(outRow)
    print outRow
    break
fout.close()
