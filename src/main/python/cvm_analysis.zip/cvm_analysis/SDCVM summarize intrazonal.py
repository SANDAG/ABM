import csv, time
import settings, sdcvm

# External libraries
ts = time.clock()
class excelOne(csv.excel):
    # define CSV dialect for Excel to avoid blank lines from default \r\n
    lineterminator = "\n"  

tazList, zonals = sdcvm.zonalProperties(fileName = settings.cvmZonalProperties)
tazDict = {}
#tazList = tazList[:25]
for t in range(len(tazList)):
    tazDict[tazList[t]] = t


# Read in skims

print "Reading in CVM skims. Time:", round(time.clock()-ts, 2)    
skimDict = {}
skimList = []


print "... Midday distance",  round(time.clock()-ts, 2) 
skimList.append("Dist_Mid")
skimDict = sdcvm.csvSkim(tazList, tazList, tazDict, tazDict,
                   settings.skimPath + "impdat_MD_Dist.TXT", skimDict, "Dist_Mid")



cvmPath = "./Outputs/"
bigDict = {}
for ind in ["IN", "RE", "SV", "TH", "WH", "FA"]:
    for tim in ["AM", "MD", "PM", "OE", "OL"]:
        print ind, tim,  round(time.clock()-ts, 2) 
        fin = open(cvmPath + "Trip_" + ind + "_" + tim + ".csv", "r")
        inFile = csv.reader(fin)
        header = inFile.next()
        for row in inFile:
            mode = row[header.index("Mode")]
            trip = int(row[header.index("Trip")])
            purp = row[header.index("TourType")]
            home = int(row[header.index("HomeZone")])
            iTaz = int(row[header.index("I")])
            jTaz = int(row[header.index("J")])

            iIdx = tazList.index(iTaz)
            jIdx = tazList.index(jTaz)

            key = (ind, mode, purp, home)
            if bigDict.has_key(key):
                pass
            else:
                bigDict[key] = [0, 0, 0]

            bigDict[key][1] = bigDict[key][1] + 1
            bigDict[key][2] = bigDict[key][2] + skimDict["Dist_Mid"][iIdx][jIdx]

            if trip == 1:
                bigDict[key][0] = bigDict[key][0] + 1

fout = open(cvmPath + "Gen and trip summ.csv", "w")
outFile = csv.writer(fout, excelOne)

keyList = bigDict.keys()
keyList.sort()
header = ["Industry", "Mode", "Purpose", "TAZ", "Tours", "Trips", "Dist"]
outFile.writerow(header)


for key in keyList:
    outRow = list(key)
    outRow.extend(bigDict[key])
    outFile.writerow(outRow)
fout.close()
